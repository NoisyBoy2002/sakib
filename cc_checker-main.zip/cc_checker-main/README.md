# CC CHECKER BOT
It is a CC checker cc bot for telegram
